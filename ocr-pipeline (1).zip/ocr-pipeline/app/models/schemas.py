"""
Data models — request/response schemas
"""

from pydantic import BaseModel, Field
from typing import Optional, List
from enum import Enum


class FieldType(str, Enum):
    name     = "name"
    company  = "company"
    email    = "email"
    phone    = "phone"
    address  = "address"
    date     = "date"
    id_num   = "id"
    business = "business"
    other    = "other"


class FieldStatus(str, Enum):
    approved = "approved"
    review   = "review"
    missing  = "missing"
    rejected = "rejected"


class BBox(BaseModel):
    x1: int
    y1: int
    x2: int
    y2: int


class ExtractedField(BaseModel):
    key:          str
    value:        str
    value_model_a: Optional[str]  = None
    value_model_b: Optional[str]  = None
    bbox:         Optional[BBox]  = None
    conf_model_a: float           = 0.0
    conf_model_b: float           = 0.0
    agreement:    float           = 0.0
    field_type:   FieldType       = FieldType.other
    validated:    bool            = False
    status:       FieldStatus     = FieldStatus.review
    note:         Optional[str]   = None


class DocumentSummary(BaseModel):
    total_fields:    int
    approved:        int
    needs_review:    int
    missing:         int
    avg_confidence:  float


class OCRResponse(BaseModel):
    document_id:   str
    job_id:        Optional[str]   = None
    processed_at:  str
    source_file:   str
    doc_type:      str             = "auto"
    fields:        List[ExtractedField]
    summary:       DocumentSummary
    processing_ms: int


class OCRRequest(BaseModel):
    """For URL-based extraction requests."""
    image_url:    Optional[str]  = None
    doc_type:     str            = "auto"   # auto | printed | handwritten | form
    fields_hint:  Optional[List[str]] = None  # Optionally hint which fields to find
    language:     str            = "en"


class BatchRequest(BaseModel):
    image_urls: List[str]
    doc_type:   str = "auto"
    language:   str = "en"


class JobStatus(BaseModel):
    job_id:     str
    status:     str            # pending | processing | done | failed
    progress:   int            = 0
    total:      int            = 1
    result:     Optional[OCRResponse] = None
    error:      Optional[str]  = None
    created_at: str
    updated_at: str
