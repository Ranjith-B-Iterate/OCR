"""
OCR Router — Main extraction endpoints
POST /api/v1/ocr/extract  → single image/PDF upload
POST /api/v1/ocr/batch    → multiple files
POST /api/v1/ocr/url      → extract from URL
"""

import io
import uuid
import logging
import asyncio
from datetime import datetime, timezone
from typing import Optional, List

import httpx
from fastapi import APIRouter, UploadFile, File, Form, Request, HTTPException, Depends
from fastapi.responses import JSONResponse

from app.models.schemas import OCRResponse, OCRRequest
from app.utils.auth import verify_api_key
from app.utils.image_utils import load_image_bytes, convert_pdf_to_images
from app.config import settings

logger = logging.getLogger("ocr_router")
router = APIRouter()


# ── Single file upload ─────────────────────────────────────────────────────
@router.post(
    "/ocr/extract",
    response_model=OCRResponse,
    summary="Extract key:value fields from uploaded image or PDF",
)
async def extract(
    request:  Request,
    file:     UploadFile = File(..., description="Image (JPG/PNG/TIFF/WEBP) or PDF"),
    doc_type: str        = Form("auto",  description="auto | printed | handwritten | form"),
    language: str        = Form("en",    description="Language code"),
    _:        None       = Depends(verify_api_key),
):
    # Validate file type
    ext = file.filename.rsplit(".", 1)[-1].lower()
    if ext not in settings.SUPPORTED_FORMATS:
        raise HTTPException(400, f"Unsupported format: {ext}. Supported: {settings.SUPPORTED_FORMATS}")

    # Read file
    raw = await file.read()
    if len(raw) > settings.MAX_IMAGE_SIZE_MB * 1024 * 1024:
        raise HTTPException(413, f"File too large. Max {settings.MAX_IMAGE_SIZE_MB}MB")

    # PDF → process first page (or all pages)
    if ext == "pdf":
        pages = convert_pdf_to_images(raw)
        if not pages:
            raise HTTPException(422, "Could not extract images from PDF")
        image_bytes = pages[0]   # Process first page; extend for multi-page
    else:
        image_bytes = load_image_bytes(raw)

    pipeline = request.app.state.model_manager.get_pipeline()
    result   = await pipeline.run(
        image_bytes=image_bytes,
        filename=file.filename,
        doc_type=doc_type,
        language=language,
    )
    return result


# ── URL-based extraction ───────────────────────────────────────────────────
@router.post(
    "/ocr/url",
    response_model=OCRResponse,
    summary="Extract from image/PDF URL",
)
async def extract_from_url(
    body:    OCRRequest,
    request: Request,
    _:       None = Depends(verify_api_key),
):
    if not body.image_url:
        raise HTTPException(400, "image_url is required")

    # Download image
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(body.image_url)
            resp.raise_for_status()
            raw = resp.content
    except Exception as e:
        raise HTTPException(422, f"Could not download image: {e}")

    image_bytes = load_image_bytes(raw)
    filename    = body.image_url.split("/")[-1] or "remote_image"

    pipeline = request.app.state.model_manager.get_pipeline()
    result   = await pipeline.run(
        image_bytes=image_bytes,
        filename=filename,
        doc_type=body.doc_type,
        language=body.language,
    )
    return result


# ── Batch upload ───────────────────────────────────────────────────────────
@router.post(
    "/ocr/batch",
    summary="Process multiple images (async, returns job_id)",
)
async def batch_extract(
    request:  Request,
    files:    List[UploadFile] = File(...),
    doc_type: str              = Form("auto"),
    _:        None             = Depends(verify_api_key),
):
    """
    Submits a batch job. Returns a job_id.
    Poll GET /api/v1/jobs/{job_id} for results.
    """
    job_id = str(uuid.uuid4())
    items  = []
    for f in files:
        raw = await f.read()
        items.append({"filename": f.filename, "raw": raw})

    # Store job in memory (use Redis in production)
    from app.utils.job_store import job_store
    job_store.create(job_id, total=len(items))

    # Run async in background
    asyncio.create_task(
        _run_batch(job_id, items, doc_type, request.app.state.model_manager)
    )

    return {
        "job_id":   job_id,
        "status":   "pending",
        "total":    len(items),
        "poll_url": f"/api/v1/jobs/{job_id}",
    }


async def _run_batch(job_id: str, items: list, doc_type: str, model_manager):
    from app.utils.job_store import job_store
    from app.utils.image_utils import load_image_bytes

    pipeline = model_manager.get_pipeline()
    results  = []

    for i, item in enumerate(items):
        try:
            image_bytes = load_image_bytes(item["raw"])
            result = await pipeline.run(
                image_bytes=image_bytes,
                filename=item["filename"],
                doc_type=doc_type,
            )
            results.append(result.model_dump())
        except Exception as e:
            logger.error(f"Batch item {item['filename']} failed: {e}")
            results.append({"error": str(e), "filename": item["filename"]})

        job_store.update(job_id, progress=i + 1)

    job_store.complete(job_id, results=results)
    logger.info(f"Batch job {job_id} complete — {len(results)} docs")
