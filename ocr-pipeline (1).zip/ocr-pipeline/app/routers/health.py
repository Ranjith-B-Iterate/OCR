"""Health check router"""
import httpx
from fastapi import APIRouter, Request
from app.config import settings

router = APIRouter()

@router.get("/health", summary="Server health + model status")
async def health(request: Request):
    # Check Ollama connectivity
    ollama_ok = False
    models_loaded = []
    try:
        async with httpx.AsyncClient(timeout=5) as client:
            resp = await client.get(f"{settings.OLLAMA_BASE_URL}/api/tags")
            if resp.status_code == 200:
                ollama_ok = True
                data = resp.json()
                models_loaded = [m["name"] for m in data.get("models", [])]
    except Exception:
        pass

    pipeline_ready = request.app.state.model_manager.pipeline is not None

    return {
        "status":        "ok" if pipeline_ready else "initializing",
        "pipeline_ready": pipeline_ready,
        "ollama":        {"connected": ollama_ok, "models": models_loaded},
        "config": {
            "extractor_model": settings.EXTRACTOR_MODEL,
            "verifier_model":  settings.VERIFIER_MODEL,
            "surya_enabled":   settings.SURYA_ENABLED,
            "trocr_enabled":   settings.TROCR_ENABLED,
        },
    }
