"""Jobs router — poll batch job status"""
from fastapi import APIRouter, HTTPException
from app.utils.job_store import job_store

router = APIRouter()

@router.get("/jobs/{job_id}", summary="Poll batch job status")
async def get_job(job_id: str):
    job = job_store.get(job_id)
    if not job:
        raise HTTPException(404, f"Job {job_id} not found")
    return job
