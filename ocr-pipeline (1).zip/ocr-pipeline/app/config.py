"""
Configuration — all settings via environment variables or .env file
"""

from pydantic_settings import BaseSettings
from typing import Optional


class Settings(BaseSettings):
    # ── Server ─────────────────────────────────────────────────────────────
    HOST: str = "0.0.0.0"
    PORT: int = 8100
    WORKERS: int = 1                    # Keep 1 for GPU sharing
    API_KEY: Optional[str] = None       # Set to require auth from clients

    # ── Ollama (Vision LLMs) ───────────────────────────────────────────────
    OLLAMA_BASE_URL: str = "http://localhost:11434"
    EXTRACTOR_MODEL: str = "qwen3-vl:8b"       # Stage 1B — Extractor
    VERIFIER_MODEL:  str = "blaifa/InternVL3_5:8b"     # Stage 2  — Verifier
    OLLAMA_TIMEOUT:  int = 120                  # seconds per LLM call

    # ── Surya OCR ──────────────────────────────────────────────────────────
    SURYA_ENABLED: bool = True
    SURYA_DEVICE:  str = "cuda"                 # "cuda" or "cpu"

    # ── TrOCR (for handwritten fallback) ──────────────────────────────────
    TROCR_ENABLED: bool = True
    TROCR_MODEL:   str = "microsoft/trocr-large-handwritten"
    TROCR_DEVICE:  str = "cuda"

    # ── Pipeline ───────────────────────────────────────────────────────────
    CONFIDENCE_AUTO_APPROVE: float = 0.85   # above this → approved
    CONFIDENCE_REVIEW:       float = 0.60   # below this → needs review
    MAX_IMAGE_SIZE_MB:       int   = 20
    SUPPORTED_FORMATS:       list  = ["jpg", "jpeg", "png", "pdf", "tiff", "webp"]

    # ── Job Queue ──────────────────────────────────────────────────────────
    REDIS_URL:      str = "redis://localhost:6379"
    JOB_TTL_HOURS:  int = 24

    # ── Storage ────────────────────────────────────────────────────────────
    DATABASE_URL:   str = "sqlite:///./ocr_results.db"
    UPLOAD_DIR:     str = "./uploads"
    LOG_LEVEL:      str = "INFO"

    class Config:
        env_file = ".env"
        extra = "ignore"


settings = Settings()
