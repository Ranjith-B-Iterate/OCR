"""
Dual-Vision OCR Pipeline — Main FastAPI Application
Runs on OCR Server. Exposes REST API for remote clients.
"""

import logging
import time
import uuid
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.routers import ocr, health, jobs
from app.services.model_manager import ModelManager
from app.utils.logger import setup_logger

logger = setup_logger("main")

# ── Global model manager (loaded once at startup) ──────────────────────────
model_manager = ModelManager()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Startup / Shutdown lifecycle."""
    logger.info("🚀 Starting OCR Pipeline Server...")
    await model_manager.initialize()
    app.state.model_manager = model_manager
    logger.info("✅ All models ready. Server is live.")
    yield
    logger.info("🛑 Shutting down OCR Pipeline Server...")
    await model_manager.cleanup()


# ── App ────────────────────────────────────────────────────────────────────
app = FastAPI(
    title="Dual-Vision OCR Pipeline API",
    description="Two-stage offline OCR: extraction + cross-verification with Vision LLMs",
    version="2.0.0",
    lifespan=lifespan,
)

# ── CORS (allow calls from any remote server) ──────────────────────────────
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],           # Restrict to specific IPs in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ── Request ID + timing middleware ─────────────────────────────────────────
@app.middleware("http")
async def add_request_metadata(request: Request, call_next):
    request_id = str(uuid.uuid4())[:8]
    request.state.request_id = request_id
    start = time.time()
    response = await call_next(request)
    duration = round((time.time() - start) * 1000, 1)
    response.headers["X-Request-ID"] = request_id
    response.headers["X-Process-Time-Ms"] = str(duration)
    logger.info(f"[{request_id}] {request.method} {request.url.path} → {response.status_code} ({duration}ms)")
    return response


# ── Global error handler ───────────────────────────────────────────────────
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Unhandled error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"error": "Internal server error", "detail": str(exc)},
    )


# ── Routers ────────────────────────────────────────────────────────────────
app.include_router(health.router, prefix="/api/v1", tags=["Health"])
app.include_router(ocr.router,    prefix="/api/v1", tags=["OCR"])
app.include_router(jobs.router,   prefix="/api/v1", tags=["Jobs"])


@app.get("/", tags=["Root"])
async def root():
    return {
        "service": "Dual-Vision OCR Pipeline",
        "version": "2.0.0",
        "docs": "/docs",
        "health": "/api/v1/health",
        "endpoints": {
            "extract": "POST /api/v1/ocr/extract",
            "batch":   "POST /api/v1/ocr/batch",
            "job":     "GET  /api/v1/jobs/{job_id}",
        },
    }
