"""Image loading and PDF conversion utilities"""
import io
import logging
from PIL import Image

logger = logging.getLogger("image_utils")

def load_image_bytes(raw: bytes, max_dim: int = 2400) -> bytes:
    """Load image, resize if too large, return JPEG bytes."""
    img = Image.open(io.BytesIO(raw)).convert("RGB")
    # Resize if image is very large (saves LLM context)
    w, h = img.size
    if max(w, h) > max_dim:
        ratio = max_dim / max(w, h)
        img = img.resize((int(w * ratio), int(h * ratio)), Image.LANCZOS)
        logger.info(f"Resized image from {w}x{h} → {img.size}")
    buf = io.BytesIO()
    img.save(buf, format="JPEG", quality=92)
    return buf.getvalue()


def convert_pdf_to_images(pdf_bytes: bytes) -> list[bytes]:
    """Convert PDF pages to JPEG image bytes."""
    try:
        import fitz  # PyMuPDF
        doc    = fitz.open(stream=pdf_bytes, filetype="pdf")
        pages  = []
        for page in doc:
            mat  = fitz.Matrix(2.0, 2.0)   # 2x zoom for clarity
            pix  = page.get_pixmap(matrix=mat)
            img  = Image.frombytes("RGB", [pix.width, pix.height], pix.samples)
            buf  = io.BytesIO()
            img.save(buf, format="JPEG", quality=92)
            pages.append(buf.getvalue())
        logger.info(f"PDF → {len(pages)} page images")
        return pages
    except ImportError:
        logger.error("PyMuPDF not installed: pip install pymupdf")
        return []
    except Exception as e:
        logger.error(f"PDF conversion failed: {e}")
        return []
