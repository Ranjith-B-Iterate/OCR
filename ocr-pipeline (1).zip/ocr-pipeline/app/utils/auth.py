"""API Key authentication"""
from fastapi import Header, HTTPException
from app.config import settings

async def verify_api_key(x_api_key: str = Header(None)):
    if settings.API_KEY and x_api_key != settings.API_KEY:
        raise HTTPException(401, "Invalid or missing API key. Pass X-Api-Key header.")
