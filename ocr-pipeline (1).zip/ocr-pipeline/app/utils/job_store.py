"""In-memory job store (replace with Redis for production)"""
from datetime import datetime, timezone
from typing import Optional

class JobStore:
    def __init__(self):
        self._jobs = {}

    def create(self, job_id: str, total: int):
        now = datetime.now(timezone.utc).isoformat()
        self._jobs[job_id] = {
            "job_id":     job_id,
            "status":     "pending",
            "progress":   0,
            "total":      total,
            "result":     None,
            "error":      None,
            "created_at": now,
            "updated_at": now,
        }

    def update(self, job_id: str, progress: int):
        if job_id in self._jobs:
            self._jobs[job_id]["progress"]   = progress
            self._jobs[job_id]["status"]     = "processing"
            self._jobs[job_id]["updated_at"] = datetime.now(timezone.utc).isoformat()

    def complete(self, job_id: str, results: list):
        if job_id in self._jobs:
            self._jobs[job_id]["status"]     = "done"
            self._jobs[job_id]["result"]     = results
            self._jobs[job_id]["progress"]   = self._jobs[job_id]["total"]
            self._jobs[job_id]["updated_at"] = datetime.now(timezone.utc).isoformat()

    def fail(self, job_id: str, error: str):
        if job_id in self._jobs:
            self._jobs[job_id]["status"]     = "failed"
            self._jobs[job_id]["error"]      = error
            self._jobs[job_id]["updated_at"] = datetime.now(timezone.utc).isoformat()

    def get(self, job_id: str) -> Optional[dict]:
        return self._jobs.get(job_id)


job_store = JobStore()
