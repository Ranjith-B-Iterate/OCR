"""
Stage 1 — OCR Service
Surya 0.6.x API: batch_text_detection + batch_recognition functions.
Detection and recognition models loaded via surya.model loaders.
"""

import logging
import io

logger = logging.getLogger("ocr_service")


def _load_surya_det():
    """Try every known path to load the Surya detection model."""
    errors = []

    # Path 1: surya 0.6.x
    try:
        from surya.model.detection.model import load_model, load_processor
        return load_model(), load_processor()
    except Exception as e:
        errors.append(f"model.detection.model: {e}")

    # Path 2: surya <=0.5.x segformer
    try:
        from surya.model.detection.segformer import load_model, load_processor
        return load_model(), load_processor()
    except Exception as e:
        errors.append(f"model.detection.segformer: {e}")

    # Path 3: surya 0.6.x alternate path
    try:
        from surya.model.detection import load_model, load_processor
        return load_model(), load_processor()
    except Exception as e:
        errors.append(f"model.detection: {e}")

    # Path 4a: surya 0.6.x — detection has no processor, model-only
    try:
        from surya.model.detection.model import load_model
        return load_model(), None   # 0.6.x needs no det processor
    except Exception as e:
        errors.append(f"model.detection.model (no proc): {e}")

    # Path 4b: surya.detection module-level load functions
    try:
        import surya.detection as det_mod
        load_model = getattr(det_mod, "load_model", None)
        load_proc  = getattr(det_mod, "load_processor", None)
        if load_model and load_proc:
            return load_model(), load_proc()
        if load_model:
            return load_model(), None
    except Exception as e:
        errors.append(f"surya.detection attrs: {e}")

    # Path 5: look for any load_* function in detection submodules
    try:
        import pkgutil, surya, importlib, inspect
        for _, modname, _ in pkgutil.walk_packages(surya.__path__, prefix="surya."):
            if "detect" not in modname.lower():
                continue
            try:
                mod = importlib.import_module(modname)
                fns = {n: f for n, f in inspect.getmembers(mod, inspect.isfunction)}
                if "load_model" in fns:
                    logger.info(f"Found load_model in {modname}")
                    m = fns["load_model"]()
                    p = fns.get("load_processor", lambda: None)()
                    return m, p
            except Exception:
                continue
    except Exception as e:
        errors.append(f"walk_packages: {e}")

    logger.error(f"All detection load paths failed:\n" + "\n".join(f"  {e}" for e in errors))
    return None, None


def _load_surya_rec():
    """Try every known path to load the Surya recognition model."""
    errors = []

    try:
        from surya.model.recognition.model import load_model
        from surya.model.recognition.processor import load_processor
        return load_model(), load_processor()
    except Exception as e:
        errors.append(f"model.recognition: {e}")

    try:
        from surya.model.recognition import load_model, load_processor
        return load_model(), load_processor()
    except Exception as e:
        errors.append(f"model.recognition init: {e}")

    logger.error(f"All recognition load paths failed:\n" + "\n".join(f"  {e}" for e in errors))
    return None, None


class SuryaOCRService:
    """Surya OCR 0.6.x — batch functions with separately loaded models."""

    def __init__(self, device: str = "cuda"):
        self.device     = device
        self._loaded    = False
        self._rec_model = None
        self._rec_proc  = None
        self._det_model = None
        self._det_proc  = None

    def load(self):
        try:
            logger.info("Loading Surya detection model...")
            det_model, det_proc = _load_surya_det()

            logger.info("Loading Surya recognition model...")
            rec_model, rec_proc = _load_surya_rec()

            if rec_model is None:
                raise RuntimeError("Recognition model failed to load")
            if det_model is None:
                raise RuntimeError(
                    "Detection model failed to load. "
                    "Run: python -c \""
                    "import pkgutil,surya,importlib,inspect; "
                    "[print(m) for _,m,_ in pkgutil.walk_packages(surya.__path__,'surya.') if 'detect' in m]\""
                )

            self._det_model = det_model
            self._det_proc  = det_proc
            self._rec_model = rec_model
            self._rec_proc  = rec_proc
            self._loaded    = True
            logger.info("✅ Surya OCR loaded successfully")

        except Exception as e:
            logger.warning(f"⚠️  Surya load failed: {e}")
            self._loaded = False

    def extract(self, image) -> list[dict]:
        if not self._loaded:
            return []

        from PIL import Image as PILImage
        if isinstance(image, bytes):
            image = PILImage.open(io.BytesIO(image)).convert("RGB")

        try:
            from surya.detection import batch_text_detection
            from surya.recognition import batch_recognition

            # Detect text regions (Surya 0.6.x has no det processor)
            if self._det_proc is not None:
                det_results = batch_text_detection([image], self._det_model, self._det_proc)
            else:
                det_results = batch_text_detection([image], self._det_model)

            # Recognise text
            bboxes = [r.bboxes for r in det_results]
            rec_results = batch_recognition(
                [image], [["en"]], self._rec_model, self._rec_proc, bboxes=bboxes
            )

            blocks = []
            for page in rec_results:
                lines = getattr(page, "text_lines", None) or []
                for idx, line in enumerate(lines):
                    text     = getattr(line, "text", "") or ""
                    conf     = float(getattr(line, "confidence", 0.9))
                    bbox_raw = getattr(line, "bbox", None)
                    bbox = None
                    if bbox_raw and isinstance(bbox_raw, (list, tuple)) and len(bbox_raw) == 4:
                        bbox = {"x1": int(bbox_raw[0]), "y1": int(bbox_raw[1]),
                                "x2": int(bbox_raw[2]), "y2": int(bbox_raw[3])}
                    if text.strip():
                        blocks.append({"text": text.strip(), "bbox": bbox,
                                       "confidence": round(conf, 3), "line_id": idx})

            logger.info(f"Surya extracted {len(blocks)} text blocks")
            return blocks

        except Exception as e:
            logger.error(f"Surya extraction failed: {e}", exc_info=True)
            return []


class TrOCRService:
    """Microsoft TrOCR — for handwritten text recognition."""

    def __init__(self, model_name: str = "microsoft/trocr-large-handwritten",
                 device: str = "cuda"):
        self.model_name = model_name
        self.device     = device
        self._loaded    = False
        self.processor  = None
        self.model      = None
        self.device_obj = "cpu"

    def load(self):
        try:
            import torch
            from transformers import TrOCRProcessor, VisionEncoderDecoderModel
            logger.info(f"Loading TrOCR: {self.model_name}...")
            self.processor  = TrOCRProcessor.from_pretrained(self.model_name)
            self.model      = VisionEncoderDecoderModel.from_pretrained(self.model_name)
            self.device_obj = "cuda" if (self.device == "cuda" and
                                          torch.cuda.is_available()) else "cpu"
            self.model      = self.model.to(self.device_obj)
            self._loaded    = True
            logger.info(f"✅ TrOCR loaded on {self.device_obj}")
        except Exception as e:
            logger.warning(f"⚠️  TrOCR load failed: {e}")
            self._loaded = False

    def extract(self, image) -> str:
        if not self._loaded:
            return ""
        import torch
        from PIL import Image
        if isinstance(image, bytes):
            image = Image.open(io.BytesIO(image)).convert("RGB")
        try:
            pv = self.processor(images=image, return_tensors="pt").pixel_values.to(self.device_obj)
            with torch.no_grad():
                ids = self.model.generate(pv)
            return self.processor.batch_decode(ids, skip_special_tokens=True)[0]
        except Exception as e:
            logger.error(f"TrOCR failed: {e}")
            return ""


class OCROrchestrator:
    def __init__(self, surya: SuryaOCRService, trocr: TrOCRService):
        self.surya = surya
        self.trocr = trocr

    def extract(self, image_bytes: bytes, doc_type: str = "auto") -> dict:
        from PIL import Image
        image = Image.open(io.BytesIO(image_bytes)).convert("RGB")

        if doc_type == "handwritten":
            raw = self.trocr.extract(image_bytes)
            return {"engine": "trocr",
                    "blocks": [{"text": raw, "bbox": None, "confidence": 0.8, "line_id": 0}],
                    "raw_text": raw}

        blocks = self.surya.extract(image) if self.surya._loaded else []

        if len(blocks) < 2 and doc_type != "printed" and self.trocr._loaded:
            raw = self.trocr.extract(image_bytes)
            if raw:
                blocks.append({"text": raw, "bbox": None, "confidence": 0.75, "line_id": 99})

        return {"engine": "surya" if self.surya._loaded else "trocr",
                "blocks": blocks,
                "raw_text": "\n".join(b["text"] for b in blocks)}
