"""
Vision LLM Service — Ollama-based offline Vision LLM calls
Stage 1B: Extractor (Qwen3-VL)
Stage 2:  Verifier  (blaifa/InternVL3_5:8b)
"""

import logging
import json
import base64
import re
import httpx
import io
from typing import Optional

logger = logging.getLogger("vision_llm")


EXTRACTOR_SYSTEM = """You are a precise document field extractor.
Given an image and OCR text blocks, identify ALL label:value pairs visible in the document.
Return ONLY valid JSON — no markdown, no preamble, no explanation.
Be thorough: capture every field you can see including name, company, email, phone, address, date, ID numbers, business type."""

EXTRACTOR_USER = """OCR Text Blocks (use as reference):
{ocr_blocks}

Extract all key:value fields from the document image.
For each field return a JSON object with:
- "key": the label/field name exactly as seen
- "value": the value for that label
- "bbox": {{"x1": int, "y1": int, "x2": int, "y2": int}} from OCR blocks, or null
- "confidence": float 0.0-1.0 (your certainty)
- "field_type": one of [name, company, email, phone, address, date, id, business, other]

Return a JSON array of these objects only. Example:
[{{"key":"Name","value":"John Silva","bbox":{{"x1":100,"y1":50,"x2":300,"y2":75}},"confidence":0.96,"field_type":"name"}}]"""


VERIFIER_SYSTEM = """You are a document verification assistant.
Given an image and a list of field keys, look carefully at the image and provide the value for each key.
Do NOT copy from any provided text — read the image directly and independently.
Return ONLY valid JSON — no markdown, no preamble."""

VERIFIER_USER = """Keys to verify (read these values directly from the image):
{keys_list}

For each key, return a JSON object with:
- "key": exactly as provided
- "value": what you read from the image for this field
- "confidence": float 0.0-1.0
- "note": any issue (blurry, partial, unclear) or null

Return a JSON array only."""


class OllamaVisionClient:
    """Client for Ollama-hosted vision LLMs."""

    def __init__(self, base_url: str, timeout: int = 120):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _image_to_base64(self, image_bytes: bytes) -> str:
        return base64.b64encode(image_bytes).decode("utf-8")

    async def call(self, model: str, system: str, user_prompt: str,
                   image_bytes: bytes) -> str:
        """Send image + prompt to Ollama, return raw text response."""
        b64 = self._image_to_base64(image_bytes)

        payload = {
            "model": model,
            "messages": [
                {"role": "system", "content": system},
                {
                    "role": "user",
                    "content": user_prompt,
                    "images": [b64],
                },
            ],
            "stream": False,
            "options": {
                "temperature": 0.1,   # Low temp for structured extraction
                "top_p": 0.9,
            },
        }

        async with httpx.AsyncClient(timeout=self.timeout) as client:
            resp = await client.post(
                f"{self.base_url}/api/chat",
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
            return data["message"]["content"]

    def _parse_json_response(self, raw: str) -> list[dict]:
        """Robustly parse JSON from LLM response."""
        # Strip markdown fences if present
        raw = re.sub(r"```json\s*", "", raw)
        raw = re.sub(r"```\s*", "", raw)
        raw = raw.strip()

        # Find JSON array
        start = raw.find("[")
        end   = raw.rfind("]") + 1
        if start == -1 or end == 0:
            logger.warning("No JSON array found in LLM response")
            return []

        try:
            return json.loads(raw[start:end])
        except json.JSONDecodeError as e:
            logger.error(f"JSON parse failed: {e}\nRaw: {raw[:500]}")
            return []


class ExtractorService:
    """Stage 1B — Vision LLM A: Extract key:value pairs from image."""

    def __init__(self, client: OllamaVisionClient, model: str):
        self.client = client
        self.model = model

    async def extract(self, image_bytes: bytes, ocr_blocks: list[dict]) -> list[dict]:
        """Returns list of extracted fields with bbox and confidence."""
        # Format OCR blocks as readable reference
        ocr_text = "\n".join(
            f"[Line {b.get('line_id',i)}] '{b['text']}' "
            f"bbox={b.get('bbox','?')} conf={b.get('confidence','?')}"
            for i, b in enumerate(ocr_blocks)
        )

        prompt = EXTRACTOR_USER.format(ocr_blocks=ocr_text)

        try:
            raw = await self.client.call(
                model=self.model,
                system=EXTRACTOR_SYSTEM,
                user_prompt=prompt,
                image_bytes=image_bytes,
            )
            fields = self.client._parse_json_response(raw)
            logger.info(f"Extractor found {len(fields)} fields")
            return fields
        except Exception as e:
            logger.error(f"Extractor LLM failed: {e}")
            return []


class VerifierService:
    """Stage 2 — Vision LLM B: Independently verify extracted values."""

    def __init__(self, client: OllamaVisionClient, model: str):
        self.client = client
        self.model = model

    async def verify(self, image_bytes: bytes, keys: list[str]) -> list[dict]:
        """Given only keys, read values from image independently."""
        keys_text = "\n".join(f"- {k}" for k in keys)
        prompt = VERIFIER_USER.format(keys_list=keys_text)

        try:
            raw = await self.client.call(
                model=self.model,
                system=VERIFIER_SYSTEM,
                user_prompt=prompt,
                image_bytes=image_bytes,
            )
            results = self.client._parse_json_response(raw)
            logger.info(f"Verifier verified {len(results)} fields")
            return results
        except Exception as e:
            logger.error(f"Verifier LLM failed: {e}")
            return []
