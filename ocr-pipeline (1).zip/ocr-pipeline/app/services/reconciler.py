"""
Stage 3 — Reconciler Service
Merges Model A (extractor) and Model B (verifier) results.
Computes agreement score, validates field formats, assigns status.
"""

import re
import logging
from difflib import SequenceMatcher
from typing import Optional
from app.models.schemas import ExtractedField, BBox, FieldType, FieldStatus, DocumentSummary
from app.config import settings

logger = logging.getLogger("reconciler")


# ── Field-level rule validators ────────────────────────────────────────────
EMAIL_RE    = re.compile(r"^[\w.+-]+@[\w-]+\.[a-z]{2,}$", re.IGNORECASE)
PHONE_RE    = re.compile(r"[\d\s\-\+\(\)]{7,20}")
URL_RE      = re.compile(r"https?://\S+|www\.\S+")


def _str_similarity(a: str, b: str) -> float:
    """Returns 0.0–1.0 similarity between two strings."""
    if not a or not b:
        return 0.0
    return SequenceMatcher(None, a.strip().lower(), b.strip().lower()).ratio()


def _validate_by_type(value: str, field_type: str) -> tuple[bool, Optional[str]]:
    """Rule-based format validation per field type."""
    if not value:
        return False, "empty value"

    if field_type == "email":
        valid = bool(EMAIL_RE.match(value.strip()))
        return valid, None if valid else "invalid email format"

    if field_type == "phone":
        valid = bool(PHONE_RE.search(value))
        return valid, None if valid else "invalid phone format"

    if field_type == "name":
        # Names should have at least 2 chars and no weird symbols
        clean = value.strip()
        valid = len(clean) >= 2 and not re.search(r"[<>{}]", clean)
        return valid, None if valid else "suspicious name format"

    # Default: any non-empty value is valid
    return True, None


def _normalize_phone(value: str) -> str:
    """Normalize phone to digits-only with + prefix."""
    digits = re.sub(r"[^\d+]", "", value)
    return digits if digits else value


def _normalize_email(value: str) -> str:
    return value.strip().lower()


def _normalize_name(value: str) -> str:
    """Title-case names."""
    return " ".join(w.capitalize() for w in value.strip().split())


def _normalize(value: str, field_type: str) -> str:
    if field_type == "phone":  return _normalize_phone(value)
    if field_type == "email":  return _normalize_email(value)
    if field_type == "name":   return _normalize_name(value)
    return value.strip()


class Reconciler:
    """Merges extractor + verifier outputs into final validated fields."""

    def __init__(self):
        self.approve_threshold = settings.CONFIDENCE_AUTO_APPROVE
        self.review_threshold  = settings.CONFIDENCE_REVIEW

    def reconcile(
        self,
        extractor_fields: list[dict],
        verifier_fields:  list[dict],
    ) -> list[ExtractedField]:
        """
        Match fields by key name, merge values, compute agreement.
        Returns list of ExtractedField with full metadata.
        """
        # Build verifier lookup by key
        verifier_map = {
            v.get("key", "").strip().lower(): v
            for v in verifier_fields
        }

        results = []

        for ef in extractor_fields:
            key        = ef.get("key", "").strip()
            val_a      = str(ef.get("value", "")).strip()
            conf_a     = float(ef.get("confidence", 0.5))
            field_type = ef.get("field_type", "other")
            raw_bbox   = ef.get("bbox")

            # Parse bbox
            bbox = None
            if raw_bbox and isinstance(raw_bbox, dict):
                try:
                    bbox = BBox(
                        x1=int(raw_bbox.get("x1", 0)),
                        y1=int(raw_bbox.get("y1", 0)),
                        x2=int(raw_bbox.get("x2", 0)),
                        y2=int(raw_bbox.get("y2", 0)),
                    )
                except Exception:
                    bbox = None

            # Match with verifier
            vf     = verifier_map.get(key.lower(), {})
            val_b  = str(vf.get("value", "")).strip()
            conf_b = float(vf.get("confidence", 0.0))
            note_b = vf.get("note")

            # Compute string-level agreement
            agreement = _str_similarity(val_a, val_b) if val_b else 0.0

            # Pick best value
            if agreement >= 0.9 or not val_b:
                best_value = val_a          # Both agree or only A has value
            elif conf_a >= conf_b:
                best_value = val_a
            else:
                best_value = val_b          # B is more confident

            # Normalize
            best_value = _normalize(best_value, field_type)

            # Rule-based validation
            validated, val_note = _validate_by_type(best_value, field_type)
            note = note_b or val_note

            # Assign status
            avg_conf = (conf_a + conf_b) / 2 if conf_b else conf_a

            if avg_conf >= self.approve_threshold and agreement >= 0.85 and validated:
                status = FieldStatus.approved
            elif avg_conf < self.review_threshold or not validated:
                status = FieldStatus.review
            elif agreement < 0.60:
                status = FieldStatus.review
            else:
                status = FieldStatus.approved

            results.append(ExtractedField(
                key=key,
                value=best_value,
                value_model_a=val_a,
                value_model_b=val_b or None,
                bbox=bbox,
                conf_model_a=round(conf_a, 3),
                conf_model_b=round(conf_b, 3),
                agreement=round(agreement, 3),
                field_type=FieldType(field_type) if field_type in FieldType.__members__ else FieldType.other,
                validated=validated,
                status=status,
                note=note,
            ))

            logger.debug(f"Field '{key}': A='{val_a}' B='{val_b}' → '{best_value}' [{status}] agree={agreement:.2f}")

        return results

    def summarize(self, fields: list[ExtractedField]) -> DocumentSummary:
        total    = len(fields)
        approved = sum(1 for f in fields if f.status == FieldStatus.approved)
        review   = sum(1 for f in fields if f.status == FieldStatus.review)
        missing  = sum(1 for f in fields if f.status == FieldStatus.missing)
        avg_conf = round(
            sum((f.conf_model_a + f.conf_model_b) / 2 for f in fields) / total, 3
        ) if total else 0.0

        return DocumentSummary(
            total_fields=total,
            approved=approved,
            needs_review=review,
            missing=missing,
            avg_confidence=avg_conf,
        )
