"""
Model Manager — Initializes and holds all model instances.
Loaded once at server startup, reused across requests.
"""

import logging
from app.config import settings
from app.services.ocr_service import SuryaOCRService, TrOCRService, OCROrchestrator
from app.services.vision_llm import OllamaVisionClient, ExtractorService, VerifierService
from app.services.reconciler import Reconciler
from app.services.pipeline import OCRPipeline

logger = logging.getLogger("model_manager")


class ModelManager:

    def __init__(self):
        self.pipeline: OCRPipeline = None

    async def initialize(self):
        """Load all models — called once at startup."""

        # ── Stage 1: OCR engines ──────────────────────────────────────────
        surya = SuryaOCRService(device=settings.SURYA_DEVICE)
        trocr = TrOCRService(
            model_name=settings.TROCR_MODEL,
            device=settings.TROCR_DEVICE,
        )

        if settings.SURYA_ENABLED:
            logger.info("Loading Surya OCR (v0.6.0 API)...")
            surya.load()
            if surya._loaded:
                logger.info("✅ Surya ready")
            else:
                logger.warning("⚠️  Surya failed to load — OCR will rely on TrOCR only")

        if settings.TROCR_ENABLED:
            logger.info("Loading TrOCR...")
            trocr.load()

        ocr_orchestrator = OCROrchestrator(surya=surya, trocr=trocr)

        # ── Stage 1B + 2: Vision LLMs via Ollama ─────────────────────────
        ollama_client = OllamaVisionClient(
            base_url=settings.OLLAMA_BASE_URL,
            timeout=settings.OLLAMA_TIMEOUT,
        )

        extractor = ExtractorService(
            client=ollama_client,
            model=settings.EXTRACTOR_MODEL,
        )

        verifier = VerifierService(
            client=ollama_client,
            model=settings.VERIFIER_MODEL,
        )

        # ── Stage 3: Reconciler ───────────────────────────────────────────
        reconciler = Reconciler()

        # ── Full pipeline ─────────────────────────────────────────────────
        self.pipeline = OCRPipeline(
            ocr=ocr_orchestrator,
            extractor=extractor,
            verifier=verifier,
            reconciler=reconciler,
        )

        logger.info("✅ ModelManager: All services initialized")

    async def cleanup(self):
        """Release GPU memory if needed."""
        logger.info("ModelManager: cleanup complete")

    def get_pipeline(self) -> "OCRPipeline":
        if self.pipeline is None:
            raise RuntimeError("Models not initialized yet")
        return self.pipeline
