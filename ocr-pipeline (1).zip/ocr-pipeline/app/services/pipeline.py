"""
OCR Pipeline — Full 3-stage orchestration
Stage 1  → OCR (Surya + TrOCR)
Stage 1B → Extractor Vision LLM (Qwen3-VL)
Stage 2  → Verifier Vision LLM (blaifa/InternVL3_5:8b)
Stage 3  → Reconciler + validator
"""

import logging
import time
import uuid
from datetime import datetime, timezone

from app.models.schemas import OCRResponse
from app.services.ocr_service import OCROrchestrator
from app.services.vision_llm import ExtractorService, VerifierService
from app.services.reconciler import Reconciler

logger = logging.getLogger("pipeline")


class OCRPipeline:

    def __init__(
        self,
        ocr:        OCROrchestrator,
        extractor:  ExtractorService,
        verifier:   VerifierService,
        reconciler: Reconciler,
    ):
        self.ocr        = ocr
        self.extractor  = extractor
        self.verifier   = verifier
        self.reconciler = reconciler

    async def run(
        self,
        image_bytes: bytes,
        filename:    str = "document",
        doc_type:    str = "auto",
        language:    str = "en",
    ) -> OCRResponse:
        """
        Full pipeline run. Returns structured OCRResponse.
        """
        doc_id  = str(uuid.uuid4())[:12]
        t_start = time.time()

        logger.info(f"[{doc_id}] Pipeline start — file={filename} doc_type={doc_type}")

        # ── Stage 1: OCR ──────────────────────────────────────────────────
        t1 = time.time()
        ocr_result = self.ocr.extract(image_bytes, doc_type=doc_type)
        ocr_blocks = ocr_result["blocks"]
        engine     = ocr_result["engine"]
        logger.info(f"[{doc_id}] Stage 1 ({engine}): {len(ocr_blocks)} blocks in {_ms(t1)}ms")

        if not ocr_blocks:
            logger.warning(f"[{doc_id}] No text detected by OCR")

        # ── Stage 1B: Extract key:value pairs ─────────────────────────────
        t2 = time.time()
        extractor_fields = await self.extractor.extract(image_bytes, ocr_blocks)
        logger.info(f"[{doc_id}] Stage 1B (extractor): {len(extractor_fields)} fields in {_ms(t2)}ms")

        if not extractor_fields:
            logger.warning(f"[{doc_id}] Extractor found no fields")
            return self._empty_response(doc_id, filename, int(_ms(t_start)))

        # ── Stage 2: Verify key:value pairs ───────────────────────────────
        t3 = time.time()
        keys = [f.get("key", "") for f in extractor_fields if f.get("key")]
        verifier_fields = await self.verifier.verify(image_bytes, keys)
        logger.info(f"[{doc_id}] Stage 2 (verifier): {len(verifier_fields)} verified in {_ms(t3)}ms")

        # ── Stage 3: Reconcile ────────────────────────────────────────────
        t4 = time.time()
        final_fields = self.reconciler.reconcile(extractor_fields, verifier_fields)
        summary      = self.reconciler.summarize(final_fields)
        logger.info(f"[{doc_id}] Stage 3 (reconcile): done in {_ms(t4)}ms")

        total_ms = int(_ms(t_start))
        logger.info(
            f"[{doc_id}] ✅ Pipeline complete — "
            f"{summary.total_fields} fields, "
            f"{summary.approved} approved, "
            f"{summary.needs_review} review — "
            f"{total_ms}ms total"
        )

        return OCRResponse(
            document_id=doc_id,
            processed_at=datetime.now(timezone.utc).isoformat(),
            source_file=filename,
            doc_type=doc_type,
            fields=final_fields,
            summary=summary,
            processing_ms=total_ms,
        )

    def _empty_response(self, doc_id, filename, ms) -> OCRResponse:
        from app.models.schemas import DocumentSummary
        return OCRResponse(
            document_id=doc_id,
            processed_at=datetime.now(timezone.utc).isoformat(),
            source_file=filename,
            doc_type="auto",
            fields=[],
            summary=DocumentSummary(total_fields=0, approved=0, needs_review=0, missing=0, avg_confidence=0.0),
            processing_ms=ms,
        )


def _ms(t_start: float) -> float:
    return round((time.time() - t_start) * 1000, 1)
