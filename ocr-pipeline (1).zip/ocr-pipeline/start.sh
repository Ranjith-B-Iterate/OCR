#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
#  start.sh — Start the OCR Pipeline server
#
#  Usage:
#    ./start.sh            → foreground (terminal must stay open)
#    ./start.sh --bg       → background with nohup (safe to close terminal)
#    ./start.sh --stop     → stop background server
#    ./start.sh --status   → check if server is running
#    ./start.sh --logs     → tail live logs
# ═══════════════════════════════════════════════════════════════════

PIDFILE="./logs/ocr-server.pid"
LOGFILE="./logs/ocr-server.log"
PORT=8100

mkdir -p logs
source venv/bin/activate

# ── Helper: kill anything on PORT ────────────────────────────────
_kill_port() {
    local port=$1
    local pid=$(lsof -ti tcp:$port 2>/dev/null)
    if [ -n "$pid" ]; then
        echo "⚠️  Port $port in use by PID $pid — killing..."
        kill -9 $pid 2>/dev/null
        sleep 1
        echo "   Port $port freed"
    fi
}

# ── STOP ──────────────────────────────────────────────────────────
if [ "$1" == "--stop" ]; then
    if [ -f "$PIDFILE" ]; then
        PID=$(cat "$PIDFILE")
        if kill -0 "$PID" 2>/dev/null; then
            echo "🛑 Stopping OCR server (PID $PID)..."
            kill "$PID"
            rm -f "$PIDFILE"
            echo "   ✅ Stopped"
        else
            echo "   ⚠️  PID $PID not running. Cleaning up pidfile."
            rm -f "$PIDFILE"
        fi
    else
        echo "   ⚠️  No pidfile found."
        PID=$(pgrep -f "uvicorn app.main:app" | head -1)
        if [ -n "$PID" ]; then
            echo "   Found uvicorn PID $PID — killing..."
            kill "$PID"
        fi
    fi
    _kill_port $PORT
    exit 0
fi

# ── STATUS ────────────────────────────────────────────────────────
if [ "$1" == "--status" ]; then
    if [ -f "$PIDFILE" ]; then
        PID=$(cat "$PIDFILE")
        if kill -0 "$PID" 2>/dev/null; then
            echo "✅ OCR server is RUNNING (PID $PID) on port $PORT"
            echo "   Swagger → http://localhost:$PORT/docs"
            echo "   Health  → http://localhost:$PORT/api/v1/health"
        else
            echo "❌ PID file exists but process is NOT running (stale pidfile)"
            rm -f "$PIDFILE"
        fi
    else
        PID=$(pgrep -f "uvicorn app.main:app" | head -1)
        if [ -n "$PID" ]; then
            echo "✅ OCR server is RUNNING (PID $PID)"
        else
            echo "❌ OCR server is NOT running"
        fi
    fi
    exit 0
fi

# ── LOGS ──────────────────────────────────────────────────────────
if [ "$1" == "--logs" ]; then
    if [ -f "$LOGFILE" ]; then
        echo "📋 Tailing $LOGFILE (Ctrl+C to exit)..."
        tail -f "$LOGFILE"
    else
        echo "⚠️  No log file found at $LOGFILE"
    fi
    exit 0
fi

# ── Ensure Ollama is running ──────────────────────────────────────
if ! pgrep -x "ollama" > /dev/null; then
    echo "🤖 Starting Ollama..."
    nohup ollama serve > logs/ollama.log 2>&1 &
    sleep 3
    echo "   ✅ Ollama started"
fi

# ── Ensure Redis is running (optional) ───────────────────────────
if ! pgrep -x "redis-server" > /dev/null; then
    echo "🔴 Starting Redis..."
    if sudo systemctl start redis-server 2>/dev/null; then
        echo "   ✅ Redis started via systemctl"
    elif sudo service redis-server start 2>/dev/null; then
        echo "   ✅ Redis started via service"
    elif command -v redis-server &>/dev/null; then
        redis-server --daemonize yes --logfile ./logs/redis.log --port 6379
        echo "   ✅ Redis started in background"
    else
        echo "   ⚠️  Redis unavailable — using in-memory store"
    fi
fi

# ── Kill anything already on port ────────────────────────────────
_kill_port $PORT

# ── BACKGROUND mode ───────────────────────────────────────────────
if [ "$1" == "--bg" ]; then
    echo "🚀 Starting OCR Pipeline in BACKGROUND on port $PORT..."
    echo "   Logs  → $LOGFILE"
    echo "   PID   → $PIDFILE"
    echo ""

    nohup uvicorn app.main:app \
        --host 0.0.0.0 \
        --port $PORT \
        --workers 1 \
        --log-level info \
        --access-log \
        >> "$LOGFILE" 2>&1 &

    echo $! > "$PIDFILE"
    sleep 3

    PID=$(cat "$PIDFILE")
    if kill -0 "$PID" 2>/dev/null; then
        echo "   ✅ Server running (PID $PID)"
        echo "   ✅ Safe to close this terminal"
        echo ""
        echo "   Commands:"
        echo "     ./start.sh --status   → check if running"
        echo "     ./start.sh --logs     → view live logs"
        echo "     ./start.sh --stop     → stop server"
        echo "     curl http://localhost:$PORT/api/v1/health"
    else
        echo "   ❌ Server failed to start. Check logs:"
        echo "     cat $LOGFILE"
        exit 1
    fi

# ── FOREGROUND mode ───────────────────────────────────────────────
else
    echo "🚀 Starting OCR Pipeline (FOREGROUND) on port $PORT..."
    echo "   Swagger → http://localhost:$PORT/docs"
    echo "   Health  → http://localhost:$PORT/api/v1/health"
    echo "   ⚠️  Use './start.sh --bg' to run persistently in background."
    echo ""
    uvicorn app.main:app \
        --host 0.0.0.0 \
        --port $PORT \
        --workers 1 \
        --log-level info \
        --access-log
fi
