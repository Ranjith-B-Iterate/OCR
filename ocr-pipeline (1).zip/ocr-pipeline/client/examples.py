"""
Example usage — run these from your remote server
"""

from ocr_client import OCRClient
import json

# ── Configure your OCR server address ─────────────────────────────────────
OCR_SERVER  = "http://YOUR_OCR_SERVER_IP:8100"
API_KEY     = "your-secret-key-here"       # Match .env API_KEY, or None if disabled

client = OCRClient(OCR_SERVER, api_key=API_KEY)


# ──────────────────────────────────────────────────────────────────────────
# EXAMPLE 1 — Check server is online and models are loaded
# ──────────────────────────────────────────────────────────────────────────
def example_health():
    print("=== Health Check ===")
    status = client.health()
    print(json.dumps(status, indent=2))


# ──────────────────────────────────────────────────────────────────────────
# EXAMPLE 2 — Extract from a single image file
# ──────────────────────────────────────────────────────────────────────────
def example_single_file():
    print("\n=== Single File Extraction ===")

    result = client.extract_file(
        filepath="business_card.jpg",
        doc_type="auto",          # auto | printed | handwritten | form
        language="en",
    )

    # Pretty-print table
    result.print_table()

    # Access specific fields
    name    = result.get("Name")
    email   = result.get("Email")
    company = result.get("Company")

    if name:
        print(f"Name:    {name.value}  (conf: {name.conf_model_a:.2f}, status: {name.status})")
    if email:
        print(f"Email:   {email.value}  (validated: {email.validated})")
    if company:
        print(f"Company: {company.value}  (bbox: {company.bbox})")

    # All as simple dict
    print("\nAll fields (key→value):")
    print(json.dumps(result.to_dict(), indent=2))

    # Only approved fields
    print(f"\nApproved fields ({len(result.approved_fields())}):")
    for f in result.approved_fields():
        print(f"  {f.key}: {f.value}")

    # Fields needing human review
    if result.review_fields():
        print(f"\n⚠️  Fields needing review ({len(result.review_fields())}):")
        for f in result.review_fields():
            print(f"  {f.key}: model_a='{f.value_model_a}' vs model_b='{f.value_model_b}' (agree={f.agreement:.2f})")


# ──────────────────────────────────────────────────────────────────────────
# EXAMPLE 3 — Extract from a PDF
# ──────────────────────────────────────────────────────────────────────────
def example_pdf():
    print("\n=== PDF Extraction ===")
    result = client.extract_file("invoice.pdf", doc_type="printed")
    result.print_table()
    return result


# ──────────────────────────────────────────────────────────────────────────
# EXAMPLE 4 — Extract from a remote URL
# ──────────────────────────────────────────────────────────────────────────
def example_url():
    print("\n=== URL Extraction ===")
    result = client.extract_url(
        image_url="https://example.com/forms/registration_form.png",
        doc_type="form",
    )
    result.print_table()


# ──────────────────────────────────────────────────────────────────────────
# EXAMPLE 5 — Batch processing multiple files
# ──────────────────────────────────────────────────────────────────────────
def example_batch():
    print("\n=== Batch Processing ===")
    files = [
        "documents/card_001.jpg",
        "documents/card_002.png",
        "documents/form_001.pdf",
    ]

    # Submit batch + wait for results
    job = client.extract_batch(files, doc_type="auto", wait=True)

    print(f"Job ID: {job['job_id']}  Status: {job['status']}")
    for i, result in enumerate(job["result"]):
        if "error" in result:
            print(f"  [{i}] ERROR: {result['error']}")
        else:
            print(f"  [{i}] {result['source_file']}: {result['summary']['total_fields']} fields")
            for field in result["fields"]:
                if field["status"] == "approved":
                    print(f"       ✅ {field['key']}: {field['value']}")


# ──────────────────────────────────────────────────────────────────────────
# EXAMPLE 6 — Extract from raw bytes (e.g. from a web upload or database)
# ──────────────────────────────────────────────────────────────────────────
def example_from_bytes():
    print("\n=== From Bytes ===")
    with open("scan.jpg", "rb") as f:
        image_bytes = f.read()

    result = client.extract_bytes(
        file_bytes=image_bytes,
        filename="scan.jpg",
        doc_type="printed",
    )
    result.print_table()


# ──────────────────────────────────────────────────────────────────────────
# EXAMPLE 7 — Full JSON output (for downstream systems)
# ──────────────────────────────────────────────────────────────────────────
def example_full_json():
    print("\n=== Full JSON Output ===")
    result = client.extract_file("id_card.jpg")

    # Full structured output per field
    output = {
        "document_id":   result.document_id,
        "processed_at":  result.processed_at,
        "processing_ms": result.processing_ms,
        "fields": [
            {
                "key":          f.key,
                "value":        f.value,
                "value_a":      f.value_model_a,
                "value_b":      f.value_model_b,
                "bbox":         {"x1": f.bbox.x1, "y1": f.bbox.y1,
                                  "x2": f.bbox.x2, "y2": f.bbox.y2} if f.bbox else None,
                "conf_a":       f.conf_model_a,
                "conf_b":       f.conf_model_b,
                "agreement":    f.agreement,
                "field_type":   f.field_type,
                "validated":    f.validated,
                "status":       f.status,
                "note":         f.note,
            }
            for f in result.fields
        ],
        "summary": {
            "total":       result.summary.total_fields,
            "approved":    result.summary.approved,
            "review":      result.summary.needs_review,
            "avg_conf":    result.summary.avg_confidence,
        }
    }

    print(json.dumps(output, indent=2))
    return output


# ──────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    example_health()
    example_single_file()
    # example_pdf()
    # example_batch()
    # example_full_json()
