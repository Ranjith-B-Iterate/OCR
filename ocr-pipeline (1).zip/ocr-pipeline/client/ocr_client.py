"""
OCR Pipeline Client SDK
Run this on your remote server to call the OCR API.

Usage:
    from ocr_client import OCRClient

    client = OCRClient("http://YOUR_OCR_SERVER_IP:8100", api_key="your-secret-key-here")
    result = client.extract_file("business_card.jpg")
    print(result.fields)
"""

import httpx
import json
import time
from pathlib import Path
from dataclasses import dataclass
from typing import Optional


# ── Data Classes ───────────────────────────────────────────────────────────

@dataclass
class BBox:
    x1: int
    y1: int
    x2: int
    y2: int

    def __repr__(self):
        return f"BBox({self.x1},{self.y1} → {self.x2},{self.y2})"


@dataclass
class Field:
    key:          str
    value:        str
    value_model_a: Optional[str]
    value_model_b: Optional[str]
    bbox:         Optional[BBox]
    conf_model_a: float
    conf_model_b: float
    agreement:    float
    field_type:   str
    validated:    bool
    status:       str
    note:         Optional[str]

    def __repr__(self):
        return (
            f"Field(key={self.key!r}, value={self.value!r}, "
            f"status={self.status}, conf_a={self.conf_model_a:.2f}, "
            f"conf_b={self.conf_model_b:.2f}, agree={self.agreement:.2f})"
        )


@dataclass
class Summary:
    total_fields:   int
    approved:       int
    needs_review:   int
    missing:        int
    avg_confidence: float


@dataclass
class OCRResult:
    document_id:   str
    processed_at:  str
    source_file:   str
    doc_type:      str
    fields:        list[Field]
    summary:       Summary
    processing_ms: int

    def get(self, key: str) -> Optional[Field]:
        """Get a field by key name (case-insensitive)."""
        key_lower = key.lower()
        for f in self.fields:
            if f.key.lower() == key_lower:
                return f
        return None

    def approved_fields(self) -> list[Field]:
        return [f for f in self.fields if f.status == "approved"]

    def review_fields(self) -> list[Field]:
        return [f for f in self.fields if f.status == "review"]

    def to_dict(self) -> dict:
        """Simple key → value dict of all fields."""
        return {f.key: f.value for f in self.fields}

    def print_table(self):
        """Print a formatted table of results."""
        print(f"\n{'─'*90}")
        print(f"  Document: {self.source_file}  |  ID: {self.document_id}  |  {self.processing_ms}ms")
        print(f"  Fields: {self.summary.total_fields} total, "
              f"{self.summary.approved} approved, "
              f"{self.summary.needs_review} review  |  "
              f"Avg conf: {self.summary.avg_confidence:.2f}")
        print(f"{'─'*90}")
        print(f"  {'KEY':<22} {'VALUE':<30} {'TYPE':<12} {'CONF-A':<8} {'CONF-B':<8} {'AGREE':<7} {'STATUS'}")
        print(f"{'─'*90}")
        for f in self.fields:
            status_icon = "✅" if f.status == "approved" else "⚠️ " if f.status == "review" else "❌"
            bbox_str = f"[{f.bbox.x1},{f.bbox.y1}]" if f.bbox else "n/a"
            print(
                f"  {f.key:<22} {f.value:<30} {f.field_type:<12} "
                f"{f.conf_model_a:<8.2f} {f.conf_model_b:<8.2f} "
                f"{f.agreement:<7.2f} {status_icon} {f.status}"
            )
        print(f"{'─'*90}\n")


# ── Client ────────────────────────────────────────────────────────────────

class OCRClient:
    """
    Client for the Dual-Vision OCR Pipeline API.

    Args:
        base_url: OCR server URL e.g. "http://192.168.1.100:8100"
        api_key:  Optional API key (must match server API_KEY setting)
        timeout:  Request timeout in seconds (default 180)
    """

    def __init__(self, base_url: str, api_key: str = None, timeout: int = 180):
        self.base_url = base_url.rstrip("/")
        self.timeout  = timeout
        self.headers  = {}
        if api_key:
            self.headers["X-Api-Key"] = api_key

    # ── Health ─────────────────────────────────────────────────────────────
    def health(self) -> dict:
        """Check server health and model status."""
        with httpx.Client(timeout=10) as c:
            resp = c.get(f"{self.base_url}/api/v1/health", headers=self.headers)
            resp.raise_for_status()
            return resp.json()

    # ── Single file ────────────────────────────────────────────────────────
    def extract_file(
        self,
        filepath:  str | Path,
        doc_type:  str = "auto",
        language:  str = "en",
    ) -> OCRResult:
        """
        Extract key:value fields from a local image or PDF file.

        Args:
            filepath: Path to image (JPG/PNG/TIFF/WEBP) or PDF
            doc_type: "auto" | "printed" | "handwritten" | "form"
            language: language code e.g. "en", "si", "ta"

        Returns:
            OCRResult with .fields, .summary, .get(key)
        """
        path = Path(filepath)
        if not path.exists():
            raise FileNotFoundError(f"File not found: {filepath}")

        with open(path, "rb") as f:
            file_bytes = f.read()

        return self.extract_bytes(
            file_bytes=file_bytes,
            filename=path.name,
            doc_type=doc_type,
            language=language,
        )

    def extract_bytes(
        self,
        file_bytes: bytes,
        filename:   str = "document.jpg",
        doc_type:   str = "auto",
        language:   str = "en",
    ) -> OCRResult:
        """Extract from raw bytes."""
        mime = _mime_type(filename)
        with httpx.Client(timeout=self.timeout, headers=self.headers) as c:
            resp = c.post(
                f"{self.base_url}/api/v1/ocr/extract",
                files={"file": (filename, file_bytes, mime)},
                data={"doc_type": doc_type, "language": language},
            )
            if resp.status_code != 200:
                raise RuntimeError(f"API error {resp.status_code}: {resp.text}")
            return _parse_response(resp.json())

    def extract_url(
        self,
        image_url: str,
        doc_type:  str = "auto",
        language:  str = "en",
    ) -> OCRResult:
        """Extract from a remote image URL."""
        with httpx.Client(timeout=self.timeout, headers=self.headers) as c:
            resp = c.post(
                f"{self.base_url}/api/v1/ocr/url",
                json={"image_url": image_url, "doc_type": doc_type, "language": language},
            )
            if resp.status_code != 200:
                raise RuntimeError(f"API error {resp.status_code}: {resp.text}")
            return _parse_response(resp.json())

    # ── Batch ──────────────────────────────────────────────────────────────
    def extract_batch(
        self,
        filepaths: list[str | Path],
        doc_type:  str = "auto",
        wait:      bool = True,
        poll_interval: int = 3,
    ) -> dict:
        """
        Submit multiple files as a batch job.

        Args:
            filepaths: List of file paths
            doc_type:  Document type hint
            wait:      If True, poll until done and return results
            poll_interval: Polling interval in seconds

        Returns:
            If wait=True: dict with job_id and results list
            If wait=False: dict with job_id and poll_url
        """
        files = []
        for fp in filepaths:
            p = Path(fp)
            files.append(("files", (p.name, open(p, "rb"), _mime_type(p.name))))

        with httpx.Client(timeout=self.timeout, headers=self.headers) as c:
            resp = c.post(
                f"{self.base_url}/api/v1/ocr/batch",
                files=files,
                data={"doc_type": doc_type},
            )
            resp.raise_for_status()
            job = resp.json()

        # Close file handles
        for _, (_, fh, _) in files:
            fh.close()

        if not wait:
            return job

        # Poll until done
        return self.wait_for_job(job["job_id"], poll_interval=poll_interval)

    def wait_for_job(self, job_id: str, poll_interval: int = 3, max_wait: int = 600) -> dict:
        """Poll a batch job until it completes."""
        waited = 0
        while waited < max_wait:
            with httpx.Client(timeout=30, headers=self.headers) as c:
                resp = c.get(f"{self.base_url}/api/v1/jobs/{job_id}")
                resp.raise_for_status()
                job = resp.json()

            status = job["status"]
            progress = job.get("progress", 0)
            total    = job.get("total", 1)
            print(f"  Job {job_id}: {status} [{progress}/{total}]", end="\r")

            if status == "done":
                print()
                return job
            if status == "failed":
                raise RuntimeError(f"Batch job failed: {job.get('error')}")

            time.sleep(poll_interval)
            waited += poll_interval

        raise TimeoutError(f"Job {job_id} did not complete within {max_wait}s")


# ── Helpers ────────────────────────────────────────────────────────────────

def _mime_type(filename: str) -> str:
    ext = str(filename).rsplit(".", 1)[-1].lower()
    return {
        "jpg": "image/jpeg", "jpeg": "image/jpeg",
        "png": "image/png",  "tiff": "image/tiff",
        "tif": "image/tiff", "webp": "image/webp",
        "pdf": "application/pdf",
    }.get(ext, "application/octet-stream")


def _parse_bbox(raw: Optional[dict]) -> Optional[BBox]:
    if not raw:
        return None
    return BBox(x1=raw["x1"], y1=raw["y1"], x2=raw["x2"], y2=raw["y2"])


def _parse_response(data: dict) -> OCRResult:
    fields = [
        Field(
            key=f["key"],
            value=f["value"],
            value_model_a=f.get("value_model_a"),
            value_model_b=f.get("value_model_b"),
            bbox=_parse_bbox(f.get("bbox")),
            conf_model_a=f.get("conf_model_a", 0.0),
            conf_model_b=f.get("conf_model_b", 0.0),
            agreement=f.get("agreement", 0.0),
            field_type=f.get("field_type", "other"),
            validated=f.get("validated", False),
            status=f.get("status", "review"),
            note=f.get("note"),
        )
        for f in data.get("fields", [])
    ]
    s = data.get("summary", {})
    summary = Summary(
        total_fields=s.get("total_fields", 0),
        approved=s.get("approved", 0),
        needs_review=s.get("needs_review", 0),
        missing=s.get("missing", 0),
        avg_confidence=s.get("avg_confidence", 0.0),
    )
    return OCRResult(
        document_id=data["document_id"],
        processed_at=data["processed_at"],
        source_file=data["source_file"],
        doc_type=data["doc_type"],
        fields=fields,
        summary=summary,
        processing_ms=data.get("processing_ms", 0),
    )
