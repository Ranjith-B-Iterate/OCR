# Dual-Vision OCR Pipeline

Two-stage offline OCR using Vision LLMs.
**Stage 1**: Surya + TrOCR (text extraction + bbox)
**Stage 1B**: Qwen3-VL-8B (key:value extraction)
**Stage 2**: InternVL3.5 (blaifa/InternVL3_5:8b) (independent verification)
**Stage 3**: Reconciler (agreement scoring + validation)

**Output per field**: `key · value · bbox[x1,y1,x2,y2] · conf_A · conf_B · agreement · status`

---

## OCR Server Setup

### 1. Clone and install
```bash
git clone <your-repo> ocr-pipeline
cd ocr-pipeline
chmod +x scripts/setup.sh start.sh
./scripts/setup.sh
```

### 2. Configure
```bash
cp .env.example .env
nano .env          # Set API_KEY and model names
```

### 3. Start server
```bash
source venv/bin/activate
./start.sh
```

Server runs on: `http://0.0.0.0:8100`

### 4. Production (systemd)
```bash
sudo cp scripts/ocr-pipeline.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable ocr-pipeline
sudo systemctl start ocr-pipeline
```

---

## API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET  | `/api/v1/health` | Server health + model status |
| POST | `/api/v1/ocr/extract` | Upload image/PDF file |
| POST | `/api/v1/ocr/url` | Extract from image URL |
| POST | `/api/v1/ocr/batch` | Batch upload (async) |
| GET  | `/api/v1/jobs/{job_id}` | Poll batch job status |
| GET  | `/docs` | Swagger UI |

---

## Remote Client (call from another server)

### Install client dependency
```bash
pip install httpx
```

### Copy client file
Copy `client/ocr_client.py` to your remote server.

### Basic usage
```python
from ocr_client import OCRClient

client = OCRClient("http://192.168.1.100:8100", api_key="your-secret-key-here")

# Check health
print(client.health())

# Extract single file
result = client.extract_file("business_card.jpg")
result.print_table()

# Get specific field
email = result.get("Email")
print(email.value, email.status, email.bbox)

# All approved fields
for f in result.approved_fields():
    print(f.key, "→", f.value)

# Simple dict
data = result.to_dict()
print(data)

# Batch
job = client.extract_batch(["doc1.jpg", "doc2.jpg"], wait=True)
```

---

## API Auth

Set `API_KEY` in `.env`. Pass as header from client:
```
X-Api-Key: your-secret-key-here
```

Leave `API_KEY` blank in `.env` to disable auth.

---

## Hardware Requirements

| Mode | RAM | GPU VRAM | Speed |
|------|-----|----------|-------|
| CPU only | 32 GB | None | ~45s/doc |
| GPU (recommended) | 32 GB | 16 GB+ | ~6s/doc |

---

## Model Config (`.env`)

```env
EXTRACTOR_MODEL=qwen3-vl:8b       # Or qwen3-vl:8b-thinking for higher accuracy
VERIFIER_MODEL=blaifa/InternVL3_5:8b       # Or blaifa/InternVL3_5:4B for less VRAM
OLLAMA_TIMEOUT=120
CONFIDENCE_AUTO_APPROVE=0.85
CONFIDENCE_REVIEW=0.60
```

| Model | Ollama Name | Size | Role |
|-------|-------------|------|------|
| Qwen3-VL 8B | `qwen3-vl:8b` | 6.1 GB | Extractor (Stage 1B) |
| InternVL3.5 8B | `blaifa/InternVL3_5:8b` | 5.7 GB | Verifier (Stage 2) |
| InternVL3.5 4B | `blaifa/InternVL3_5:4B` | 3.4 GB | Verifier — low VRAM option |

```json
{
  "document_id": "a1b2c3d4e5f6",
  "fields": [
    {
      "key": "Name",
      "value": "John Perera",
      "value_model_a": "John Perera",
      "value_model_b": "John Perera",
      "bbox": {"x1": 142, "y1": 88, "x2": 310, "y2": 112},
      "conf_model_a": 0.97,
      "conf_model_b": 0.95,
      "agreement": 1.0,
      "field_type": "name",
      "validated": true,
      "status": "approved"
    }
  ],
  "summary": {
    "total_fields": 8,
    "approved": 7,
    "needs_review": 1,
    "avg_confidence": 0.92
  },
  "processing_ms": 6200
}
```
