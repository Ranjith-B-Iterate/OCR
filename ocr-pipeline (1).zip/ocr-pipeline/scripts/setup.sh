#!/bin/bash
# ═══════════════════════════════════════════════════════════════════
#  OCR Pipeline — Server Setup Script
#  Run this ONCE on your OCR server to install everything
# ═══════════════════════════════════════════════════════════════════

set -e   # exit on error
echo "🚀 Setting up Dual-Vision OCR Pipeline Server..."

# Disable exit-on-error for optional services (Redis)
# We re-enable strict mode after critical steps complete

# ── 1. System packages ──────────────────────────────────────────
echo "📦 Installing system packages..."
sudo apt-get update -qq
sudo apt-get install -y python3.11 python3.11-venv python3-pip \
    libgl1-mesa-glx libglib2.0-0 libsm6 libxrender1 libxext6 \
    redis-server curl git

# ── 2. Python venv ──────────────────────────────────────────────
echo "🐍 Creating Python virtual environment..."
python3.11 -m venv venv
source venv/bin/activate

# ── 3. Python dependencies ──────────────────────────────────────
echo "📥 Installing Python dependencies..."
pip install --upgrade pip
pip install -r requirements.txt

# ── 4. Install Ollama ───────────────────────────────────────────
echo "🤖 Installing Ollama..."
if ! command -v ollama &> /dev/null; then
    curl -fsSL https://ollama.com/install.sh | sh
else
    echo "   Ollama already installed"
fi

# ── 5. Pull Vision LLM models ───────────────────────────────────
echo "⬇️  Pulling Vision LLM models (this may take a while)..."
ollama pull qwen3-vl:8b
ollama pull blaifa/InternVL3_5:8b    # 5.7GB — use blaifa/InternVL3_5:4B (3.4GB) if low on VRAM

# ── 6. Configure environment ────────────────────────────────────
if [ ! -f .env ]; then
    cp .env.example .env
    echo "⚠️  Created .env from .env.example — edit your API_KEY!"
fi

# ── 7. Create directories ───────────────────────────────────────
mkdir -p uploads logs

# ── 8. Start Redis (optional — used for batch jobs only) ────────
set +e   # Redis failure should NOT abort setup
echo "🔴 Starting Redis..."

# Try systemctl first (works on most Ubuntu setups)
if sudo systemctl start redis-server 2>/dev/null; then
    sudo systemctl enable redis-server 2>/dev/null || true
    echo "   ✅ Redis started via systemctl"

# Try service command as fallback
elif sudo service redis-server start 2>/dev/null; then
    echo "   ✅ Redis started via service"

# Run Redis directly in background as final fallback
elif command -v redis-server &> /dev/null; then
    redis-server --daemonize yes --logfile ./logs/redis.log --port 6379
    echo "   ✅ Redis started in background (daemonized)"

else
    echo "   ⚠️  Redis could not start — batch jobs will use in-memory store"
    echo "      Single-file extraction still works perfectly without Redis."
    echo "      To fix Redis manually: sudo apt-get install --reinstall redis-server"
fi

echo ""
echo "✅ Setup complete!"
echo ""
echo "Next steps:"
echo "  1. Edit .env and set your API_KEY"
echo "  2. Run:  source venv/bin/activate"
echo "  3. Run:  ./start.sh"
echo "  4. Test: curl http://localhost:8100/api/v1/health"
